package com.ricardo.atvpratica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class Music extends AppCompatActivity {
    public Button btnVoltar2;
    public WebView imagem1;
    public MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music);

        btnVoltar2 = findViewById(R.id.btnVoltar2);
        imagem1 = findViewById(R.id.imagem1);
        mp = MediaPlayer.create(this, R.raw.music);
        mp.start();


        WebSettings gif = imagem1.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/espada.gif";
        imagem1.loadUrl(caminho);

        btnVoltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playVoltar();
            }
        });

    }

    public void playVoltar() {
        Intent main = new Intent(this, MainActivity.class);
        startActivity(main);
        mp.stop();

    }
}