package com.ricardo.atvpratica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public Button btnHistoria, btnMusic, btnSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHistoria = findViewById(R.id.btnHistoria);
        btnMusic = findViewById(R.id.btnMusic);
        btnSensor = findViewById(R.id.btnSensor);

        btnHistoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playHistoria();

            }
        });

        btnMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playMusic();
            }
        });

        btnSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSensor();
            }
        });


    }
    public void playHistoria() {
        Intent janelaH = new Intent(this, Historia.class);
        startActivity(janelaH);
    }
    public void playMusic() {
        Intent janelaM = new Intent(this, Music.class);
        startActivity(janelaM);
    }

    public void playSensor() {
        Intent janelaS = new Intent(this, Sensores.class);
        startActivity(janelaS);
    }
}