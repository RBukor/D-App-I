package com.ricardo.atvpratica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Sensores extends AppCompatActivity implements SensorEventListener {
    public TextView retorno;
    public Sensor proximidade;
    public SensorManager medir;
    public Button btnvoltar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensores);

        medir = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        proximidade = medir.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        retorno = findViewById(R.id.retorno);
        btnvoltar3 = findViewById(R.id.btnVoltar3);


        btnvoltar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playVoltar();
            }
        });
    }

    @Override
    protected void onResume() {
        medir.registerListener(this, proximidade, SensorManager.SENSOR_DELAY_NORMAL);
        super.onResume();
    }

    @Override
    protected void onPause() {
        medir.unregisterListener(this, proximidade);
        super.onPause();
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.values[0] == 0)
        {
            retorno.setText("CALMA AÍ IRMÃO, TA PERTÃO");
        }
        else
        {
            retorno.setText("TA LONGE AÍ MANO");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    public void playVoltar() {
        Intent main = new Intent(this, MainActivity.class);
        startActivity(main);

    }
}