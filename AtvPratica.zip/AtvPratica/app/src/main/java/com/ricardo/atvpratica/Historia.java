package com.ricardo.atvpratica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class Historia extends AppCompatActivity {
    public Button btnVoltar1;
    public WebView imagem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historia);

        btnVoltar1 = findViewById(R.id.btnVoltar1);
        imagem = findViewById(R.id.imagem);

        WebSettings gif = imagem.getSettings();
        gif.setJavaScriptEnabled(true);
        String caminho = "file:android_asset/giphy.gif";
        imagem.loadUrl(caminho);

        btnVoltar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playVoltar();
            }
        });

    }
    public void playVoltar() {
        Intent main = new Intent(this, MainActivity.class);
        startActivity(main);
    }


}